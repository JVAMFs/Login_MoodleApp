package com.example.login_transretail

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.cardview.widget.CardView


class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val login = findViewById<CardView>(R.id.btn_Login)
        val inputNIK = findViewById<EditText>(R.id.inputNIK)
        val inputPassword = findViewById<EditText>(R.id.inputPassword)

        login.setOnClickListener {
            val nik = inputNIK.text.toString()
            val password = inputPassword.text.toString()
            if (nik.isEmpty()|| password.isEmpty()) {
                Toast.makeText(this, "Please Insert Nik and Password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if(nik == "0001" || password == "admin01"){
                val progressDialog = ProgressDialog(this,
                        R.style.Theme_MaterialComponents_Light_Dialog)
                progressDialog.isIndeterminate = true
                progressDialog.setMessage("Loading...")
                progressDialog.show()
                val intent = Intent (this,Dashboard::class.java)
                startActivity(intent)
                finish()
            }
        }

    }
}